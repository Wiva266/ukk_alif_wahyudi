<?php

$nik      = $_POST['nik'];
$nama     = $_POST['nama'];
$username = $_POST['username'];
$pass = $_POST['pass'];
$telepon  = $_POST['telepon'];

include 'koneksi.php';

$sql = "INSERT INTO masyarakat (nik, nama, username, pass, telepon) VALUES('$nik', '$nama', '$username', '$pass', '$telepon')";

$query = mysqli_query($conn, $sql);

if($query){
    echo"<script>alert('anda berhasil mendaftar!'); window.location.assign('login.php');</script>";
}else{
    echo"<script>alert('maaf anda tidak berhasil mendaftar!'); window.location.assign('register.php');</script>";
}
