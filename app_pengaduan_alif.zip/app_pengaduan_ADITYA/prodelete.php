<?php
include 'koneksi.php';
$id = $_GET['id'];
if(empty($id)){
  header("Location:?url=lihat-pengaduan");
}

$query = mysqli_query($conn, "DELETE FROM pengaduan WHERE id_pengaduan= '$id'");

?>

    if(mysqli_query($conn, $sql)){
        echo "<script>alert('anda berhasil menghapus laporan'); window.location.assign('masyarakat.php?url=lihat-pengaduan');</script>";
    }else{
        echo "<script>alert('anda gagal menghapus laporan'); window.location.assign('masyarakat.php?url=lihat-pengaduan');</script>";
    
};

